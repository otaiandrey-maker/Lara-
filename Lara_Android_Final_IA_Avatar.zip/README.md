# Lara — IA + Avatar

Este projeto é a nova versão do APK da Lara.

Inclui:
- Avatar feminino desenhado nativamente no Android.
- Animação enquanto a Lara está respondendo.
- Conversa por texto.
- Entrada por voz em português do Brasil.
- Resposta falada por Text-to-Speech.
- Integração com a API de Responses da OpenAI.
- Workflow do GitHub Actions para gerar o APK sem usar Render.

## Como gerar o APK

1. Envie estes arquivos para o repositório GitHub da Lara.
2. Abra a aba **Actions**.
3. Selecione **Gerar APK da Lara**.
4. Toque em **Run workflow**.
5. Quando terminar, abra a execução e baixe o artefato **Lara-debug**.
6. Instale o APK no Android.

## Importante sobre a chave da OpenAI

A versão atual permite informar a chave dentro do aplicativo apenas para facilitar o teste pessoal.

Para uma versão pública/distribuída, NÃO coloque uma chave da OpenAI dentro do APK. A própria OpenAI recomenda que as chamadas sejam feitas por um backend seguro, porque chaves em aplicativos móveis podem ser extraídas. 

package com.lara.assistente

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var apiKeyInput: EditText
    private lateinit var avatar: LaraAvatarView
    private val history = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 24, 28, 20)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }

        val title = TextView(this).apply {
            text = "Lara"
            textSize = 32f
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "Sua assistente virtual"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xFF666666.toInt())
        }

        avatar = LaraAvatarView(this)
        val avatarParams = LinearLayout.LayoutParams(-1, 300).apply {
            topMargin = 8
            bottomMargin = 8
        }

        chat = TextView(this).apply {
            text = "Olá! Eu sou a Lara. Fale comigo por texto ou toque em 🎙."
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(10, 10, 10, 16)
        }

        val scroll = ScrollView(this).apply {
            addView(chat)
        }

        apiKeyInput = EditText(this).apply {
            hint = "Chave da API OpenAI (sk-...)"
            textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(getPreferences(MODE_PRIVATE).getString("api_key", ""))
        }

        val saveKey = Button(this).apply {
            text = "Salvar chave da IA"
            setOnClickListener {
                getPreferences(MODE_PRIVATE).edit()
                    .putString("api_key", apiKeyInput.text.toString().trim())
                    .apply()
                Toast.makeText(this@MainActivity, "Chave salva neste aparelho.", Toast.LENGTH_SHORT).show()
            }
        }

        input = EditText(this).apply {
            hint = "Digite uma mensagem..."
            textSize = 17f
            singleLine = false
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        val send = Button(this).apply {
            text = "Enviar"
            setOnClickListener { answer(input.text.toString()) }
        }

        val voice = Button(this).apply {
            text = "🎙 Falar"
            setOnClickListener { startVoice() }
        }

        row.addView(send, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(voice, LinearLayout.LayoutParams(0, -2, 1f))

        root.addView(title)
        root.addView(subtitle)
        root.addView(avatar, avatarParams)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(apiKeyInput)
        root.addView(saveKey)
        root.addView(input)
        root.addView(row)

        setContentView(root)
    }

    private fun answer(text: String) {
        if (text.isBlank()) return

        val apiKey = apiKeyInput.text.toString().trim()
        if (apiKey.isBlank()) {
            chat.text = "Para ativar minha inteligência artificial, informe sua chave da API OpenAI e toque em \"Salvar chave da IA\"."
            return
        }

        history.add("Usuário: $text")
        chat.text = "Lara está pensando..."
        input.text.clear()
        avatar.setSpeaking(true)

        thread {
            try {
                val reply = callOpenAI(apiKey, buildPrompt())
                history.add("Lara: $reply")

                runOnUiThread {
                    avatar.setSpeaking(true)
                    chat.text = reply
                    tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "lara")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    avatar.setSpeaking(false)
                    chat.text = "Não consegui falar com a IA agora.\n\n${e.message ?: "Erro desconhecido"}"
                }
            }
        }
    }

    private fun buildPrompt(): String {
        val recent = history.takeLast(12).joinToString("\n")
        return """
            Você é Lara, uma assistente virtual feminina em português do Brasil.
            Sua personalidade é carinhosa, inteligente, natural, educada e objetiva.
            Ajude o usuário em tarefas, dúvidas, organização e conversas.
            Fale de forma humana, sem repetir que é uma IA a todo momento.
            Quando o usuário pedir algo perigoso ou ilegal, não ajude a executar.

            Conversa recente:
            $recent

            Responda à última mensagem do usuário.
        """.trimIndent()
    }

    private fun callOpenAI(apiKey: String, prompt: String): String {
        val url = URL("https://api.openai.com/v1/responses")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json")
        }

        val body = JSONObject()
            .put("model", "gpt-5-mini")
            .put("input", prompt)
            .toString()

        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val responseText = stream.bufferedReader().use { it.readText() }

        if (code !in 200..299) {
            throw Exception("HTTP $code: ${extractError(responseText)}")
        }

        val json = JSONObject(responseText)
        val outputText = json.optString("output_text", "")
        if (outputText.isNotBlank()) return outputText

        val output = json.optJSONArray("output")
        if (output != null) {
            for (i in 0 until output.length()) {
                val item = output.optJSONObject(i) ?: continue
                val content = item.optJSONArray("content") ?: continue
                for (j in 0 until content.length()) {
                    val part = content.optJSONObject(j) ?: continue
                    val text = part.optString("text", "")
                    if (text.isNotBlank()) return text
                }
            }
        }

        return "Recebi uma resposta, mas não consegui ler o texto."
    }

    private fun extractError(text: String): String {
        return try {
            JSONObject(text).optJSONObject("error")?.optString("message", text) ?: text
        } catch (_: Exception) {
            text
        }
    }

    private fun startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com a Lara")
        }
        startActivityForResult(intent, 20)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 20 && resultCode == RESULT_OK) {
            val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!result.isNullOrEmpty()) {
                input.setText(result[0])
                answer(result[0])
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("pt", "BR")
        }
    }

    override fun onDestroy() {
        avatar.setSpeaking(false)
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}

package com.lara.assistente

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.sin

class LaraAvatarView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var speaking = false
    private var t = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var animator: ValueAnimator? = null

    fun setSpeaking(value: Boolean) {
        speaking = value
        if (value) {
            if (animator == null) {
                animator = ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 900
                    repeatCount = ValueAnimator.INFINITE
                    addUpdateListener {
                        t = it.animatedValue as Float
                        invalidate()
                    }
                    start()
                }
            }
        } else {
            animator?.cancel()
            animator = null
            t = 0f
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val pulse = if (speaking) 4f * sin(t * Math.PI * 2).toFloat() else 0f

        // Background glow
        paint.color = Color.rgb(246, 240, 255)
        canvas.drawCircle(cx, h * 0.48f, minOf(w, h) * 0.43f + pulse, paint)

        // Shoulders / body
        paint.color = Color.rgb(117, 72, 170)
        val body = RectF(w * 0.22f, h * 0.66f, w * 0.78f, h * 1.02f)
        canvas.drawRoundRect(body, 45f, 45f, paint)

        // Neck
        paint.color = Color.rgb(247, 198, 164)
        canvas.drawRoundRect(
            RectF(w * 0.44f, h * 0.55f, w * 0.56f, h * 0.72f),
            20f, 20f, paint
        )

        // Hair behind face
        paint.color = Color.rgb(58, 35, 28)
        canvas.drawOval(RectF(w * 0.28f, h * 0.10f, w * 0.72f, h * 0.68f), paint)

        // Face
        paint.color = Color.rgb(249, 205, 174)
        canvas.drawOval(RectF(w * 0.34f, h * 0.19f, w * 0.66f, h * 0.63f), paint)

        // Hair fringe
        paint.color = Color.rgb(58, 35, 28)
        val fringe = Path().apply {
            moveTo(w * 0.34f, h * 0.30f)
            quadTo(w * 0.40f, h * 0.12f, w * 0.56f, h * 0.18f)
            quadTo(w * 0.67f, h * 0.20f, w * 0.66f, h * 0.34f)
            quadTo(w * 0.56f, h * 0.27f, w * 0.48f, h * 0.33f)
            quadTo(w * 0.40f, h * 0.37f, w * 0.34f, h * 0.30f)
        }
        canvas.drawPath(fringe, paint)

        // Eyes
        paint.color = Color.DKGRAY
        canvas.drawOval(RectF(w * 0.405f, h * 0.39f, w * 0.435f, h * 0.425f), paint)
        canvas.drawOval(RectF(w * 0.565f, h * 0.39f, w * 0.595f, h * 0.425f), paint)

        // Smile / speaking mouth
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = Color.rgb(150, 65, 85)
        val mouth = RectF(w * 0.445f, h * 0.47f, w * 0.555f, h * (if (speaking) 0.55f else 0.535f))
        if (speaking) canvas.drawOval(mouth, paint)
        else canvas.drawArc(mouth, 15f, 150f, false, paint)
        paint.style = Paint.Style.FILL

        // Small status dot
        paint.color = if (speaking) Color.rgb(46, 180, 92) else Color.rgb(150, 150, 150)
        canvas.drawCircle(w * 0.76f, h * 0.18f, 10f, paint)
    }
}

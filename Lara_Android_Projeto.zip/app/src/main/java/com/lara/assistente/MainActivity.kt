package com.lara.assistente

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var chat: TextView
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 24)
        }

        val title = TextView(this).apply {
            text = "Lara"
            textSize = 32f
            setPadding(0, 0, 0, 8)
        }

        val subtitle = TextView(this).apply {
            text = "Sua assistente virtual"
            textSize = 16f
        }

        chat = TextView(this).apply {
            text = "Olá! Eu sou a Lara. Como posso ajudar você?"
            textSize = 18f
            setPadding(0, 40, 0, 20)
        }

        input = EditText(this).apply {
            hint = "Digite uma mensagem..."
            textSize = 17f
        }

        val send = Button(this).apply {
            text = "Enviar"
            setOnClickListener { answer(input.text.toString()) }
        }

        val voice = Button(this).apply {
            text = "🎙 Falar com Lara"
            setOnClickListener { startVoice() }
        }

        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(chat, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(input)
        layout.addView(send)
        layout.addView(voice)
        setContentView(layout)
    }

    private fun answer(text: String) {
        if (text.isBlank()) return
        val reply = "Entendi. Você disse: $text\n\nSou a Lara e esta é minha primeira versão. Podemos adicionar inteligência artificial, memória, comandos e uma voz personalizada."
        chat.text = reply
        tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "lara")
        input.text.clear()
    }

    private fun startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com a Lara")
        }
        startActivityForResult(intent, 20)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 20 && resultCode == RESULT_OK) {
            val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!result.isNullOrEmpty()) {
                input.setText(result[0])
                answer(result[0])
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("pt", "BR")
        }
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}

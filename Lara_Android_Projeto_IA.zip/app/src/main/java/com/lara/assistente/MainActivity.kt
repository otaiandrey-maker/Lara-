package com.lara.assistente

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var apiKeyInput: EditText
    private val history = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 24)
        }

        val title = TextView(this).apply {
            text = "Lara"
            textSize = 32f
            setPadding(0, 0, 0, 8)
        }

        val subtitle = TextView(this).apply {
            text = "Sua assistente virtual"
            textSize = 16f
        }

        chat = TextView(this).apply {
            text = "Olá! Eu sou a Lara. Agora posso conversar com você usando inteligência artificial."
            textSize = 18f
            setPadding(0, 40, 0, 20)
        }

        apiKeyInput = EditText(this).apply {
            hint = "Chave da API OpenAI (sk-...)"
            textSize = 15f
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(getPreferences(MODE_PRIVATE).getString("api_key", ""))
        }

        input = EditText(this).apply {
            hint = "Digite uma mensagem..."
            textSize = 17f
        }

        val send = Button(this).apply {
            text = "Enviar"
            setOnClickListener { answer(input.text.toString()) }
        }

        val voice = Button(this).apply {
            text = "🎙 Falar com Lara"
            setOnClickListener { startVoice() }
        }

        val saveKey = Button(this).apply {
            text = "Salvar chave da IA"
            setOnClickListener {
                getPreferences(MODE_PRIVATE).edit()
                    .putString("api_key", apiKeyInput.text.toString().trim())
                    .apply()
                Toast.makeText(this@MainActivity, "Chave salva neste aparelho.", Toast.LENGTH_SHORT).show()
            }
        }

        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(chat, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(apiKeyInput)
        layout.addView(saveKey)
        layout.addView(input)
        layout.addView(send)
        layout.addView(voice)
        setContentView(layout)
    }

    private fun answer(text: String) {
        if (text.isBlank()) return

        val apiKey = apiKeyInput.text.toString().trim()
        if (apiKey.isBlank()) {
            chat.text = "Para eu conversar com você usando IA, primeiro informe sua chave da API OpenAI e toque em \"Salvar chave da IA\"."
            return
        }

        history.add("Usuário: $text")
        chat.text = "Lara está pensando..."
        input.text.clear()

        thread {
            try {
                val prompt = buildPrompt()
                val reply = callOpenAI(apiKey, prompt)
                history.add("Lara: $reply")

                runOnUiThread {
                    chat.text = reply
                    tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "lara")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    chat.text = "Não consegui falar com a IA agora.\n\nErro: ${e.message ?: "erro desconhecido"}"
                }
            }
        }
    }

    private fun buildPrompt(): String {
        val recent = history.takeLast(12).joinToString("\n")
        return """
            Você é Lara, uma assistente virtual em português do Brasil.
            Seja natural, educada, objetiva e útil. Responda como uma assistente pessoal.
            Não diga que é apenas uma primeira versão.

            Conversa recente:
            $recent

            Responda à última mensagem do usuário.
        """.trimIndent()
    }

    private fun callOpenAI(apiKey: String, prompt: String): String {
        val url = URL("https://api.openai.com/v1/responses")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json")
        }

        val body = JSONObject()
            .put("model", "gpt-5-mini")
            .put("input", prompt)
            .toString()

        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val responseText = stream.bufferedReader().use { it.readText() }

        if (code !in 200..299) {
            throw Exception("HTTP $code: ${extractError(responseText)}")
        }

        val json = JSONObject(responseText)
        val outputText = json.optString("output_text", "")
        if (outputText.isNotBlank()) return outputText

        val output = json.optJSONArray("output")
        if (output != null) {
            for (i in 0 until output.length()) {
                val item = output.optJSONObject(i) ?: continue
                val content = item.optJSONArray("content") ?: continue
                for (j in 0 until content.length()) {
                    val part = content.optJSONObject(j) ?: continue
                    val text = part.optString("text", "")
                    if (text.isNotBlank()) return text
                }
            }
        }

        return "Recebi uma resposta, mas não consegui ler o texto."
    }

    private fun extractError(text: String): String {
        return try {
            JSONObject(text).optJSONObject("error")?.optString("message", text) ?: text
        } catch (_: Exception) {
            text
        }
    }

    private fun startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com a Lara")
        }
        startActivityForResult(intent, 20)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 20 && resultCode == RESULT_OK) {
            val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!result.isNullOrEmpty()) {
                input.setText(result[0])
                answer(result[0])
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("pt", "BR")
        }
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
